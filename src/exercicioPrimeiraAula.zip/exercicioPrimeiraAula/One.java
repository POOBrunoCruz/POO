package exercicioPrimeiraAula;

/**
 * Created by bruno on 06/10/16.
 */
public class One {
    public static void main(String[] args) {

        System.out.print("white world");
    }
}
