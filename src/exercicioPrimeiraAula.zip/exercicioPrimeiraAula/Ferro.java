package exercicioPrimeiraAula;

/**
 * Created by bruno on 25/10/16.
 */
public class Ferro {
    String marca;
    String model;
    String cor;
    int qtdMod;
    int potencia;
    String tipoPlug;

    public Ferro(){

    }

    public Ferro(String marca, String model, String cor, int qtdMod,int potencia, String tipoPlug){
        marca = "Panasonic";
        model = "asx";
        cor = "Branco";
        qtdMod = 3;
        potencia = 110;
        tipoPlug = "3 pinos de 20A";
    }

    public void FuncionarFerro(String action){
        boolean op = false;
        if (action == "ligado") {
            op = true;
        }else if(action == "desligado") {
            op = false;
        }
    }
    public void EscolherModo(int op){
        switch(op){
            case 1:
            case 2:
            case 3:
            default:
        }
    }
}
